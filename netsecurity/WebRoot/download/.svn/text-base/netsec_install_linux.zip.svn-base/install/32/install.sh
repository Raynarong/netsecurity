mkdir -p /usr/lib/netsect
cp -r ./build/. /usr/lib/netsect
chmod 777 /usr/lib/netsect/netsec
chmod 777 /usr/lib/netsect/netsectool
ln -s  /usr/lib/netsect/netsec /usr/bin/netsec
ln -s /usr/lib/netsect/netsectool /usr/bin/netsectool

cp /usr/lib/netsect/netsecserv /etc/init.d/netsecserv
chmod 755 /etc/init.d/netsecserv

ln -s /etc/init.d/netsecserv /etc/rc0.d/S100netsec
ln -s /etc/init.d/netsecserv /etc/rc1.d/S100netsec
ln -s /etc/init.d/netsecserv /etc/rc2.d/S100netsec
ln -s /etc/init.d/netsecserv /etc/rc3.d/S100netsec
ln -s /etc/init.d/netsecserv /etc/rc4.d/S100netsec
ln -s /etc/init.d/netsecserv /etc/rc5.d/S100netsec
ln -s /etc/init.d/netsecserv /etc/rc6.d/S100netsec


echo 'Install Complete'
netsec
echo 'Please run netsectool to regist, login and bind'
