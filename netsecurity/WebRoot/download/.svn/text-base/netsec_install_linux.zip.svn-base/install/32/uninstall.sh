rm -rf /usr/lib/netsect
rm -rf /usr/bin/netsec
rm -rf  /usr/bin/netsectool 

rm -rf /etc/init.d/netsecserv

rm -rf /etc/rc0.d/S100netsec
rm -rf /etc/rc1.d/S100netsec
rm -rf /etc/rc2.d/S100netsec
rm -rf /etc/rc3.d/S100netsec
rm -rf /etc/rc4.d/S100netsec
rm -rf /etc/rc5.d/S100netsec
rm -rf /etc/rc6.d/S100netsec


echo 'Uninstall Complete'